package com.openclassrooms.rental.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MessagesResponseDTO {
    private String message;
}
